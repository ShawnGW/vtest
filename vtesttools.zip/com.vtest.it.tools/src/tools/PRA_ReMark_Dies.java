package tools;

public class PRA_ReMark_Dies {
	public static final String[] MarkDieArray={"331:30","331:29","331:28","331:27","331:26","331:25","331:24"};
}
