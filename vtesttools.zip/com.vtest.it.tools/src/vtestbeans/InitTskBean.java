package vtestbeans;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import javax.naming.directory.NoSuchAttributeException;

import mesinfor.GetInnerLot;
import mesinfor.GetMesInformations;
import mestools.GetLotConfigFromMes;
import parseMapping.TskProberMappingParse;
import properties.GetRawdataProperties;
import rawdata.Rawdata;

public class InitTskBean extends InitBean implements Rawdata{

	private LinkedHashMap<String, String> properties=new LinkedHashMap<>();
	private HashMap<String, String> DieMap=new HashMap<>();
	private HashMap<String, String> skipAndMarkDieMap=new HashMap<>();
	private HashMap<Integer, Integer> Bin_summary_Map=new HashMap<>();
		
	public InitTskBean(String customerLot,File mapping,HashMap<String, String> customerLotConfig,HashMap<String, String> basicsInfor) throws IOException, NoSuchFieldException, NoSuchAttributeException {
		GetMesInformations getMesInformations=new GetMesInformations();
		GetRawdataProperties getRawdataProperties=new GetRawdataProperties();
		TskProberMappingParse tskProberMappingParse=new TskProberMappingParse();
		
		//get inner lot ; get tsk mapping information ;
		int gpibBin=Integer.valueOf(customerLotConfig.get("gpib").substring(0, 1));		
		HashMap<String, String> tskMappingResult=tskProberMappingParse.Get(mapping,gpibBin,Bin_summary_Map,DieMap,skipAndMarkDieMap);
		String waferid=tskMappingResult.get("Wafer ID");
		waferid=SlotModify.modify(customerLotConfig, waferid);
		String innerlot=GetInnerLot.get(waferid);
		String cp=tskMappingResult.get("CP Process");
		HashMap<String, String> resultMap=getMesInformations.getInfor(new GetLotConfigFromMes(innerlot), GetMesInformations.TYPE_CONFIG);
		properties=initProperties(tskMappingResult,properties, getRawdataProperties, resultMap, cp,waferid,innerlot);		
		initBasicInfo(basicsInfor, properties);
	}
	@Override
	public LinkedHashMap<String, String> getProperties() {
		// TODO Auto-generated method stub
		return properties;
	}
	@Override
	public HashMap<String, String> getTestDieMap() {
		// TODO Auto-generated method stub
		return DieMap;
	}
	@Override
	public HashMap<String, String> getMarkAndSkipDieMap() {
		// TODO Auto-generated method stub
		return skipAndMarkDieMap;
	}
	@Override
	public TreeMap<Integer, Integer> getbinSummary() {
		// TODO Auto-generated method stub
		return new TreeMap<>(Bin_summary_Map);
	}

}
