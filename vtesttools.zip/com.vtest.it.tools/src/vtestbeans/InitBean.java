package vtestbeans;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.directory.NoSuchAttributeException;

import mesinfor.GetMesInformations;
import mesinfor.GetProcessYield;
import mesinfor.GetTesterAndProber;
import mesinfor.getWaferIdYield;
import mestools.GetLotConfigFromMes;
import properties.GetRawdataProperties;

public class InitBean {
	public LinkedHashMap<String, String> initProperties(HashMap<String, String> MappingResult,LinkedHashMap<String, String> properties,GetRawdataProperties getRawdataProperties,HashMap<String, String> resultMap,String cp,String waferid,String innerlot) throws IOException
	{
		GetTesterAndProber getTesterAndProber=new GetTesterAndProber();
		Set<String> propertiesSet=resultMap.keySet();
		HashMap<String, String> configMap=getRawdataProperties.getConfigs();
		 properties=getRawdataProperties.getProperties();
		Set<String> configSet=configMap.keySet();
		for (String config : configSet) {
			if (config.contains("$")) {
				String regex=config.replace("$", ".{1}");
				regex=regex.replace("[", "(");
				regex=regex.replace("]", ")");
				Pattern pattern=Pattern.compile(regex);
				for (String propertie : propertiesSet)
				{
					Matcher matcher=pattern.matcher(propertie);
					if (matcher.find()&&propertie.contains(cp+"T0")) {
						properties.put(configMap.get(config), resultMap.get(propertie).trim());
					}
				}
			}
			if (config.endsWith("#")) {
				String regex="CP.{1}T0";
				Pattern pattern=Pattern.compile(regex);
				config=config.substring(0, config.length()-1);
				StringBuilder stringBuilder=new StringBuilder();
				for (String propertie : propertiesSet)
				{
					if (propertie.contains(config)) {
						String value=resultMap.get(propertie);
						Matcher matcher=pattern.matcher(value);
						if (matcher.find()) {
							stringBuilder.append(value+";");
						}
					}
				}
				config=config+"#";
				properties.put(configMap.get(config), stringBuilder.toString().trim());
			}
			if (config.endsWith("*")) {
				config=config.substring(0, config.length()-1);				
				for (String propertie : propertiesSet) {
					if (propertie.contains(config)) {
						if (resultMap.get(propertie).contains(cp+"T0")) {	
							String[] content=resultMap.get(propertie).split(":");
							properties.put(configMap.get(config+"*"), content.length>1?content[1]:content[0]);
						}
					}
				}				
				config=config+"*";
				if (properties.get(configMap.get(config)).equals(config)) {
					properties.put(configMap.get(config), "NA");
				}
			}else {
				if (resultMap.containsKey(config)) {
					properties.put(configMap.get(config), resultMap.get(config));
				}else
				{
					if (properties.get(configMap.get(config)).equals(config)) {
						properties.put(configMap.get(config), "NA");
					}
				}
			}
		}
		
		Set<String> keyset=MappingResult.keySet();
		for (String key : keyset) {
			String value=MappingResult.get(key);
			if (!value.equals("NA")) {
				properties.put(key, value);	
			}		
		}
		
		String processYield="NA";
		try {
			processYield=GetProcessYield.getYield(properties.get("Process Yield"), cp);
		} catch (Exception e) {
			// TODO: handle exception
			//e.printStackTrace();
		}
		properties.put("Process Yield", processYield);
				
		getWaferIdYield getWaferIdYield=new getWaferIdYield();
		String lot=properties.get("Lot ID");		
		HashMap<String, String> cpYieldMap=getWaferIdYield.get(lot, waferid);
		Set<String> yieldMap=cpYieldMap.keySet();
		StringBuffer SB=new StringBuffer();
		for (String process : yieldMap) {
			SB.append(process+"&"+cpYieldMap.get(process)+"%;");
		}
		String cpYields=SB.toString();
		if (cpYields.equals("")) {
			cpYields=properties.get("CP Process")+"&"+properties.get("Wafer Yield")+";";
		}
		properties.put("CP Yields", cpYields);
		
		if (properties.get("DataBase").equals("STDF")&&properties.get("Slot").equals("NA")) {
			GetMesInformations getMesInformations=new GetMesInformations();
			try {
				String[] waferIdArray=getMesInformations.getInfor(new GetLotConfigFromMes(innerlot.split("\\.")[0]), GetMesInformations.TYPE_CONFIG).get("[WaferIDs]").split(",");
				for (int i = 0; i < waferIdArray.length; i++) {
					if (waferIdArray[i].equals(waferid)) {
						properties.put("Slot", String.valueOf(i+1));
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		if (properties.get("DataBase").equals("TSK")&&properties.get("Wafer_Sequence").equals("25-1")) {
			properties.put("RightID", String.valueOf(26-Integer.valueOf(properties.get("Slot"))));
		}else {
			properties.put("RightID", properties.get("Slot"));
		}
		
		properties.put("Wafer ID", waferid);
		
		// get tester,prober,probercard; init properties;
		HashMap<String, String> testerAndProber=getTesterAndProber.Get(innerlot, cp,true);
		Set<String> testersMap=testerAndProber.keySet();
		for (String key : testersMap) {
			String value=testerAndProber.get(key);
			if (!value.equals("NA")) {
				properties.put(key, value);
			}
		}
		return properties;
	}
	public void initBasicInfo(HashMap<String, String> basicsInfor,LinkedHashMap<String, String> properties) throws NoSuchAttributeException
	{
		basicsInfor.put("customerCode", properties.get("Customer Code"));
		basicsInfor.put("device", properties.get("Device Name"));
		basicsInfor.put("lot", properties.get("Lot ID"));
		basicsInfor.put("waferId", properties.get("Wafer ID"));
		basicsInfor.put("cp", properties.get("CP Process"));
		if (properties.get("Customer Code").equals("NA")) {
			throw new NoSuchAttributeException();
		}
	}
}
