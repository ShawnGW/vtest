package vtestbeans;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeMap;
import javax.naming.directory.NoSuchAttributeException;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import mesinfor.GetInnerLot;
import mesinfor.GetMesInformations;
import mestools.GetLotConfigFromMes;
import parseMapping.TelProberMappingSmallDieParse;
import properties.GetRawdataProperties;
import rawdata.Rawdata;
import tools.PRA_ReMark_Dies;

public class InitTelSmallDieDieBean extends InitBean implements Rawdata{
	private LinkedHashMap<String, String> properties=new LinkedHashMap<>();
	private HashMap<String, String> DieMap=new HashMap<>();
	private HashMap<String, String> skipAndMarkDieMap=new HashMap<>();
	private HashMap<Integer, Integer> Bin_summary_Map=new HashMap<>();
	
	public InitTelSmallDieDieBean(File mapping,HashMap<String, String> daResultMap,HashMap<String, String> waferIdDaResultMap,HashMap<String, String> basicsInfor) throws IOException, ParserConfigurationException, SAXException, NoSuchAttributeException {
		GetMesInformations getMesInformations=new GetMesInformations();
		GetRawdataProperties getRawdataProperties=new GetRawdataProperties();	
		TelProberMappingSmallDieParse telProberMappingSmallDieParse=new TelProberMappingSmallDieParse();
		
		HashMap<String, String> telMappingResult=telProberMappingSmallDieParse.Get(mapping, waferIdDaResultMap, Bin_summary_Map, DieMap, skipAndMarkDieMap);
		String waferid=telMappingResult.get("Wafer ID");
		String innerlot=GetInnerLot.get(waferid);	

		String cp=daResultMap.get("cp");		
		HashMap<String, String> resultMap=getMesInformations.getInfor(new GetLotConfigFromMes(innerlot), GetMesInformations.TYPE_CONFIG);
		properties=initProperties(telMappingResult,properties, getRawdataProperties, resultMap, cp,waferid,innerlot);
		ModifyProperties.modify(properties, Bin_summary_Map);
		
		properties.put("CP Process", cp);
		properties.put("Operator", daResultMap.get("op"));
		
		try {
			if (properties.get("Customer Code").equals("PRA")&&properties.get("Device Name").equals("P25Q40HD")) {
				String[] reMarkDies=PRA_ReMark_Dies.MarkDieArray;
				HashMap<Integer, Integer> praMarkDieMapBinSummary=new HashMap<>();
				for (String coordinate : reMarkDies) {
					String coordinateX=coordinate.split(":")[0];
					String coordinateY=coordinate.split(":")[1];
					String key=String.format("%4s", coordinateX)+String.format("%4s", coordinateY);
					Integer binvalue=Integer.valueOf(DieMap.get(key).substring(4, 8).trim());
					if (praMarkDieMapBinSummary.containsKey(binvalue)) {
						praMarkDieMapBinSummary.put(binvalue, praMarkDieMapBinSummary.get(binvalue)+1);
					}else {
						praMarkDieMapBinSummary.put(binvalue,1);
					}
					DieMap.put(key, String.format("%4s", "5")+String.format("%4s", "5")+String.format("%4s", "0"));
				}
				ArrayList<Integer> passBinList=new ArrayList<>();
				String[] passBins=properties.get("@Pass Bins").split(",");
				for (String passBin : passBins) {
					passBinList.add(Integer.valueOf(passBin));
				}
				Set<Integer> binSet=praMarkDieMapBinSummary.keySet();
				Integer passDieByMark=0;
				for (Integer bin : binSet) {
					if (passBinList.contains(bin)) {
						passDieByMark+=praMarkDieMapBinSummary.get(bin);
					}
				}
				Integer rawdataPassDie=Integer.valueOf(properties.get("Pass Die"));
				Integer rawdataFailDie=Integer.valueOf(properties.get("Fail Die"));
				if (passDieByMark!=0) {
					rawdataPassDie=rawdataPassDie-passDieByMark;
					rawdataFailDie=rawdataFailDie+passDieByMark;
					properties.put("Pass Die", String.valueOf(rawdataPassDie));
					properties.put("Fail Die", String.valueOf(rawdataFailDie));
					properties.put("Wafer Yield", String.format("%4.2f", (double)rawdataPassDie*100/(rawdataPassDie+rawdataFailDie))+"%");
				}
				praMarkDieMapBinSummary.remove(5);
				Set<Integer> otherBinSet=praMarkDieMapBinSummary.keySet();
				Integer fifthBinSum=0;
				for (Integer otherBin : otherBinSet) {
					Integer otherBinVlaue=praMarkDieMapBinSummary.get(otherBin);
					fifthBinSum+=otherBinVlaue;
					Bin_summary_Map.put(otherBin, Bin_summary_Map.get(otherBin)-otherBinVlaue);
				}
				Bin_summary_Map.put(5, Bin_summary_Map.containsKey(5)?Bin_summary_Map.get(5)+fifthBinSum:fifthBinSum);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		initBasicInfo(basicsInfor, properties);
	}
	@Override
	public LinkedHashMap<String, String> getProperties() {
		// TODO Auto-generated method stub
		return properties;
	}
	@Override
	public HashMap<String, String> getTestDieMap() {
		// TODO Auto-generated method stub
		return DieMap;
	}
	@Override
	public HashMap<String, String> getMarkAndSkipDieMap() {
		// TODO Auto-generated method stub
		return skipAndMarkDieMap;
	}
	@Override
	public TreeMap<Integer, Integer> getbinSummary() {
		// TODO Auto-generated method stub
		return new TreeMap<>(Bin_summary_Map);
	}

}
