package vtestbeans;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;
import javax.naming.directory.NoSuchAttributeException;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import mesinfor.GetInnerLot;
import mesinfor.GetMesInformations;
import mestools.GetLotConfigFromMes;
import parseMapping.TelProberMappingNormalParse;
import properties.GetRawdataProperties;
import rawdata.Rawdata;

public class InitTelNormalDieBean extends InitBean implements Rawdata{
	private LinkedHashMap<String, String> properties=new LinkedHashMap<>();
	private HashMap<String, String> DieMap=new HashMap<>();
	private HashMap<String, String> skipAndMarkDieMap=new HashMap<>();
	private HashMap<Integer, Integer> Bin_summary_Map=new HashMap<>();
	
	public InitTelNormalDieBean(File mapping,HashMap<String, String> datResultMap,HashMap<String, String> basicsInfor) throws IOException, ParserConfigurationException, SAXException, NoSuchAttributeException {
		GetMesInformations getMesInformations=new GetMesInformations();
		GetRawdataProperties getRawdataProperties=new GetRawdataProperties();
		TelProberMappingNormalParse telProberMappingNormalParse=new TelProberMappingNormalParse();
		
		HashMap<String, String> telMappingResult=telProberMappingNormalParse.Get(mapping, Bin_summary_Map, DieMap, skipAndMarkDieMap);
		String waferid=telMappingResult.get("Wafer ID");
		String innerlot=GetInnerLot.get(waferid);	
		String cp=datResultMap.get("cp");	
		HashMap<String, String> resultMap=getMesInformations.getInfor(new GetLotConfigFromMes(innerlot), GetMesInformations.TYPE_CONFIG);
		properties=initProperties(telMappingResult,properties, getRawdataProperties, resultMap, cp,waferid,innerlot);		
		ModifyProperties.modify(properties, Bin_summary_Map);
		properties.put("CP Process", cp);
		properties.put("Operator", datResultMap.get("op"));
		initBasicInfo(basicsInfor, properties);
	}
	@Override
	public LinkedHashMap<String, String> getProperties() {
		// TODO Auto-generated method stub
		return properties;
	}
	@Override
	public HashMap<String, String> getTestDieMap() {
		// TODO Auto-generated method stub
		return DieMap;
	}
	@Override
	public HashMap<String, String> getMarkAndSkipDieMap() {
		// TODO Auto-generated method stub
		return skipAndMarkDieMap;
	}
	@Override
	public TreeMap<Integer, Integer> getbinSummary() {
		// TODO Auto-generated method stub
		return new TreeMap<>(Bin_summary_Map);
	}

}
