package vtestbeans;

import java.util.HashMap;
import java.util.Set;

import mesinfor.GetInnerLot;
import mesinfor.GetMesInformations;
import mestools.GetLotConfigFromMes;

public class test {
	public static void main(String[] args) {
		System.out.println(GetInnerLot.get("T1AA05-25G3"));
		GetMesInformations getMesInformations=new GetMesInformations();
		HashMap<String, String> hashMap=getMesInformations.getInfor(new GetLotConfigFromMes("AMCQC16002"), GetMesInformations.TYPE_CONFIG);
		Set<String> set=hashMap.keySet();
		for (String string : set) {
			System.out.println(string+" : "+hashMap.get(string));
		}
	}
}
