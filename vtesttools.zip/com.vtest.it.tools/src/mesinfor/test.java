package mesinfor;

import java.util.HashMap;
import java.util.Set;

import mestools.GetLotConfigFromMes;

public class test {
	public static void main(String[] args) {
		GetMesInformations getMesInformations=new GetMesInformations();
		HashMap<String, String> hashMap=getMesInformations.getInfor(new GetLotConfigFromMes("FA83-6230"), GetMesInformations.TYPE_CONFIG);
		Set<String> set=hashMap.keySet();
		for (String string : set) {
			System.out.println(string+" : "+hashMap.get(string));
		}
	}
}
