package generateMain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.io.FileUtils;

import mesinfor.WaferIdBinSummaryWrite;
import tools.GetShieldDevice;

public class GenerateRawdataParent {
	public SimpleDateFormat dateFormat=new SimpleDateFormat("yyyyMMddHHmmss");
	public void dealFile(File mapping,File vtestRawdata,String customerCode,String device,String lotNum,String cp,String waferId,TreeMap<Integer, Integer> binSummary)
	{	
		try {
			if (customerCode.equals("GCK")) {
				File GCKBackDirectory=new File("/prod/AnomalyDatalog/GCK/MAP/"+lotNum);
				if(!GCKBackDirectory.exists())
					GCKBackDirectory.mkdirs();							
				
				File GCKBackupFile=new File("/prod/AnomalyDatalog/GCK/MAP/"+lotNum+"/"+mapping.getName());
				if (GCKBackupFile.exists()) {
					GCKBackupFile.delete();
				}
				FileUtils.copyFile(mapping, GCKBackupFile);
			}
			File waferIdLog=new File("/TestReport/CustReport/"+customerCode+"/"+device+"/"+lotNum+"/"+cp+"/error.log");			
			if (waferIdLog.exists()) {
			FileReader reader=new FileReader(waferIdLog);
			BufferedReader bufferedReader=new BufferedReader(reader);
			String content;
			ArrayList<String> contentList=new ArrayList<>();
			ArrayList<String> otherContentList=new ArrayList<>();
			while((content=bufferedReader.readLine())!=null)
			{
				if (content.startsWith(waferId)) {
					contentList.add(content);
				}else {
					otherContentList.add(content);
				}
			 }
			 bufferedReader.close();
			 if (otherContentList.size()!=0) {
				FileWriter writer=new FileWriter(waferIdLog);
				PrintWriter printWriter=new PrintWriter(writer);
				for (String otherContent : otherContentList) {
					printWriter.print(otherContent+"\r\n");
				}
				printWriter.flush();
				printWriter.close();
		   	 }else
		   	 {
		   		waferIdLog.delete();
		   	 }		
			}
			
			File proberMappingBackUpDirectory=new File("/prod/mapbackup/"+customerCode+"/"+device+"/"+lotNum+"/"+cp);
			if (!proberMappingBackUpDirectory.exists()) {
				proberMappingBackUpDirectory.mkdir();
			}
			String mappingName=mapping.getName();
			mappingName=mappingName+"_"+(dateFormat.format(new Date()));
			File proberMappingBackFile=new File("/prod/mapbackup/"+customerCode+"/"+device+"/"+lotNum+"/"+cp+"/"+mappingName);
			FileUtils.copyFile(mapping, proberMappingBackFile);
			
			
			boolean specialCustomer=false;
			HashMap<String, ArrayList<String>> shieldMap=GetShieldDevice.get();
			if (shieldMap.containsKey(customerCode)) {
				if (shieldMap.get(customerCode).contains("ALL")) {
					specialCustomer=true;
				}else if(shieldMap.get(customerCode).contains(device)){
					specialCustomer=true;
				}
			}
			if (specialCustomer) {
				FileUtils.forceDelete(vtestRawdata);
				return;
			}
			
			File resultDirectory=new File("/TestReport/RawData/"+customerCode+"/"+device+"/"+lotNum+"/"+cp);
			if (!resultDirectory.exists()) {
				resultDirectory.mkdirs();
			}
			File resultRawdataTemp=new File("/TestReport/RawData/"+customerCode+"/"+device+"/"+lotNum+"/"+cp+"/"+waferId+".raw");
			if (resultRawdataTemp.exists()) {
				resultRawdataTemp.delete();
			}
			HashMap<String, String> resultMap=new HashMap<>();
			resultMap.put("lot", lotNum);
			resultMap.put("waferId", waferId);
			resultMap.put("cp", cp);			
			WaferIdBinSummaryWrite write=new WaferIdBinSummaryWrite();
			write.write(resultMap, binSummary);
			FileUtils.copyFile(vtestRawdata, resultRawdataTemp);
			FileUtils.forceDelete(vtestRawdata);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public  void dealFile(File mapping,File vtestRawdata,String customerCode,String device,String lotNum,String cp,String waferId,TreeMap<Integer, Integer> binSummary,HashMap<String, String> log)
	{
		try {
			dealFile(mapping,vtestRawdata, customerCode, device, lotNum, cp, waferId,binSummary);
			File waferIdLog=new File("/TestReport/CustReport/"+customerCode+"/"+device+"/"+lotNum+"/"+cp+"/error.log");
			if (!waferIdLog.getParentFile().exists()) {
				waferIdLog.getParentFile().mkdirs();
			}
			File totalErrorLog=new File("/TestReport/errorLog/"+(new SimpleDateFormat("yyyyMMdd")).format(new Date())+".log");
			if (!totalErrorLog.getParentFile().exists()) {
				totalErrorLog.getParentFile().mkdirs();
			}
			FileWriter totalWriter=new FileWriter(totalErrorLog,true);
			PrintWriter totalPrint=new PrintWriter(totalWriter);
			FileWriter writer=new FileWriter(waferIdLog,true);
			PrintWriter out=new PrintWriter(writer);
			Set<String> checkItems=log.keySet();
			for (String chekItem : checkItems) {
				if (!chekItem.contains("Type")) {
					out.print(waferId+" & "+log.get(chekItem)+"\r\n");
					totalPrint.print("TSK platform:"+customerCode+":"+device+":"+lotNum+":"+cp+":"+waferId);
					totalPrint.print(" & "+log.get(chekItem)+"\r\n");
				}
			}
			totalPrint.flush();
			totalPrint.close();
			out.flush();
			out.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
