package parseRawdataInterface;

import java.util.LinkedHashMap;

public interface GetPropertiesFromRawdata {
	abstract LinkedHashMap<String, String> getProperties();
}
