package mestools;

public interface MesInterface {
	abstract String getURL();
}
