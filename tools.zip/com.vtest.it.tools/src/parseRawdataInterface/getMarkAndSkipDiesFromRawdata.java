package parseRawdataInterface;

import java.util.HashMap;

public interface getMarkAndSkipDiesFromRawdata {
	abstract HashMap<String, String> getMarkAndSkipDies();
	abstract String[][] getMarkAndSkipDiesDimensionalArray();
}
