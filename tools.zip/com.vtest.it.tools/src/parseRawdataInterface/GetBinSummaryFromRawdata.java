package parseRawdataInterface;

import java.util.TreeMap;

public interface GetBinSummaryFromRawdata {
	abstract TreeMap<Integer, Integer> getBinSummary();
}
