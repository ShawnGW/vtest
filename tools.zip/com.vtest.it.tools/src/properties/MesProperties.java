package properties;

public class MesProperties {
	public static final String SERVICE_HOST="http://211.149.241.228";
	public static final String SERVICE_URL="http://211.149.241.228/vt_mes/ajaxprocess.aspx";
	public static final String VERIFICATION_CODE="65195845153489435181";
}
